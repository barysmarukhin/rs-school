import React, { Component } from 'react';

class DayView extends Component {
  render() {
    return (
      <div>
        Empty DayView Component
      </div>
    );
  }
}

export default DayView;
