import React, {Component} from 'react';

class AgendaView extends Component {
  render() {
    return (
      <div>
        Empty AgendaView Component
      </div>
    );
  }
}

export default AgendaView;
