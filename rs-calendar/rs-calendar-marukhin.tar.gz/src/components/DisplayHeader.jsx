import React, {Component} from 'react';

class DisplayHeader extends Component {
  render() {
    return (
      <div>
        Empty DisplayHeader Component
      </div>
    );
  }
}

export default DisplayHeader;
